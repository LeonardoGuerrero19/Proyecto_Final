import pygame, random, sys, time
#Variables a necesitar
ancho = 800
altura = 600
negro = (0,0,0) #color negro
blanco = (255,255,255) #Color blanco

pygame.init() # Inicia la libreria pygame
#-------Sonidos-------------
pygame.mixer.init() #Inicia la libreria de sonidos de pygame
sol = pygame.mixer.Sound("salto.wav") #Se declara para despues ponerla en la funcion de saltar.
pygame.mixer.Sound.set_volume(sol,0.2)
hurt = pygame.mixer.Sound("hitHurt.wav")
#past = pygame.mixer.Sound("EfectosDeSonido/pastocaminar.mp3")#Se declara el sonido al moverse para despues llamar la funcion.
#pygame.mixer.music.load("Otra musica.mp3")#Se introduce la musica, se activa la musica y se modifica el volumen que queremos.
#pygame.mixer.music.play(1)
#pygame.mixer.music.set_volume(0.7)
pantalla = pygame.display.set_mode((ancho, altura))
pygame.display.set_caption("Dark Sky")
icono = pygame.image.load("player50.png")
pygame.display.set_icon(icono)
clock = pygame.time.Clock()
#Codigo de la clase del juegador o lo que compone a todo el jugador(movimiento,imagen, efectos de sonido.)
#----Funcion para dibujar un texto e pantalla.
def draw_text(surface, text, size, x, y):
    fuente = pygame.font.SysFont("serif", size)
    text_surface = fuente.render(text, True, blanco)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surface.blit(text_surface, text_rect)
class Jugador(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.images_right = []
        self.images_left = []
        self.index = 0
        self.counter = 0
    
        for num in range(1, 4):
            img_right = pygame.image.load(f'run{num}.png')
            img_left = pygame.transform.flip(img_right, True, False)
            self.images_right.append(img_right)
            self.images_left.append(img_left)
        
        self.image = self.images_right[self.index]
        self.rect = self.image.get_rect()
        self.rect.x = ancho // 2
        self.rect.y = altura -35
        self.velocidad_y = 0
        self.jumped = False
        self.direction = 0

        #Vida
        self.hp = 100
        self.vidas = 3
        self.progreso = 0
    #Parte del codigo que indica el movimiento del personaje.(Velocidad, limites.)
    def update(self):
        dx = 0
        dy = 0
        walk_cooldown = 5

        self.speed_x = 0
        self.speed_y = 0
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            dx -= 5
            self.counter += 1
            self.direction = -1
            #jugador.animate2()
        if key[pygame.K_RIGHT]:
            dx += 5
            self.counter += 1
            self.direction = 1
          #  jugador.animate()
        if key[pygame.K_LEFT] == False and key[pygame.K_RIGHT] == False:
            self.counter = 0
            self.index = 0
            if self.direction == 1:
                self.image = self.images_right[self.index]
            if self.direction == -1:
                self.image = self.images_left[self.index]
                
        if self.counter > walk_cooldown:
            self.counter = 0
            self.index += 1
            if self.index >= len(self.images_right):
                self.index = 0
            if self.direction == 1:
                self.image = self.images_right[self.index]
            if self.direction == -1:
                self.image = self.images_left[self.index]
            
        #Limitando el borde derecho.
        if self.rect.right > ancho:
            self.rect.right = ancho
        #limitando el borde izquierdo.
        if self.rect.left < 0:
            self.rect.left = 0
        #Limitando el borde superior
        if self.rect.top < 450:
            self.rect.top = 450
        #Limitando el borde inferior.
        if self.rect.bottom > 550:
            self.rect.bottom = 550
        
        self.rect.x += dx
        self.rect.y += dy

class Soles(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("SpriteSolvacio.png").convert()
        self.image.set_colorkey(negro)
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(ancho - self.rect.width)
        self.rect.y = random.randrange(-100,-40)
        self.speedy = random.randrange(3,5)
        self.speedx = random.randrange(-2,2)

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        #Si los soles salen de la pantalla por la altura o por los lados este if los devuelve a la parte de arriba.
        if self.rect.top > altura + 10 or self.rect.left < -25 or self.rect.right > ancho + 25:
            self.rect.x = random.randrange(ancho - self.rect.width)
            self.rect.y = random.randrange(-100,-40)
            self.speedy = random.randrange(1,5)
class Perros(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("enemy2.png").convert()
        self.image.set_colorkey(negro)
        self.rect = self.image.get_rect()
        ###self.rect.x = random.randrange(ancho - self.rect.width)
        self.rect.y = random.randrange(-0, 600)
        #self.speedy = random.randrange(2,7)
        self.speedx = random.randrange(7) #mueve a la derecha

    def update(self):
        #self.rect.y += self.speedy
        self.rect.x += self.speedx
        #Si el perro sale de los bordes lo vuelve a posicionar arriba.
        #if self.rect.top > altura + 10 or self.rect.left < -25 or self.rect.right > ancho + 25:
        if self.rect.right > ancho + 10 or self.rect.left <  -25:
            ###self.rect.x = random.randrange(ancho - self.rect.width)
            self.rect.y = random.randrange(-0,600)
            #self.speedy = random.randrange(2,7)
            self.speedx = random.randrange(-2,0)

#---Barra de vida o funcion de vidas---
def barra_hp(pantalla, x, y, hp):
    verde = (0,255,100)
    largo= 200
    ancho = 25
    calculo = int(jugador.hp / 100 * largo)
    borde = pygame.Rect(30, 40, largo, ancho)
    rectangulo = pygame.Rect(30, 40, calculo, ancho)
    pygame.draw.rect(pantalla, negro, borde, 3)
    pygame.draw.rect(pantalla, verde, rectangulo)
    Cora = pygame.image.load("corazon.png").convert()
    Cora.set_colorkey(negro)
    pantalla.blit(pygame.transform.scale(Cora, (50, 50)), (0, 30))
    Coragris = pygame.image.load("corawarning.png").convert()
    Coragris.set_colorkey(negro)

    if jugador.hp < 0:
        jugador.hp = 0
    if jugador.hp < 30:
        pantalla.blit(pygame.transform.scale(Coragris, (50, 50)), (0, 30))

def barra_progreso(pantalla,x,y, progreso):
    amarillo = (255,255,0)

    largo= 200
    ancho = 25
    calculo = int(jugador.progreso / 100 * largo)
    borde = pygame.Rect(20, y, largo, ancho)
    rectangulo = pygame.Rect(20, y, calculo, ancho)
    pygame.draw.rect(pantalla, negro, borde, 3)
    pygame.draw.rect(pantalla, amarillo, rectangulo)
    sol_img = pygame.image.load("SpriteSolvacio.png").convert()
    sol_img.set_colorkey(negro)
    pantalla.blit(pygame.transform.scale(sol_img, (45, 45)), (218, 0))
    #Coragris = pygame.image.load("warning.png").convert()
    #Coragris.set_colorkey(negro)

    #if jugador.progreso < 0:
        #jugador.progreso = 0
    #if jugador.progreso < 30:
        #pantalla.blit(pygame.transform.scale(Coragris, (25, 25)), (545,15))


def game_over():
    #Texto a mostrar.
    game_over_texto = Fuente.render("Nivel no finalizado volviendo al menú", True, (250,250,250))
    tiempo_texto = Fuente.render("Tiempo realizado: "+str(Tiempo),True,(255,255,255))
    marcador_texto = Fuente.render("Soles recolectados: "+str(marcador),True,(255,255,255))
    #Dibujar elementos
    pantalla.blit(fondo, [0,0])
    pantalla.blit(game_over_texto, (ancho/2 - (game_over_texto.get_width()/2), (altura/2 - marcador_texto.get_height() * 4)))
    pantalla.blit(tiempo_texto, (ancho/2 - (tiempo_texto.get_width()/2), (altura/2 - tiempo_texto.get_height() * 2)))
    pantalla.blit(marcador_texto, (ancho/2 - (marcador_texto.get_width()/2), (altura/2 - marcador_texto.get_height() * 3)))
    
    for jugador in all_sprites:
        jugador.kill

    pygame.display.update()
    time.sleep(5)
    pygame.quit()
    sys.exit()

def game_win():
    #Texto a mostrar.
    game_over_texto = Fuente.render("Nivel uno completado correctamente!", True, (250,250,250))
    tiempo_texto = Fuente.render("Tiempo realizado: "+str(Tiempo),True,(255,255,255))
    marcador_texto = Fuente.render("Soles recolectados: "+str(marcador),True,(255,255,255))
    #Dibujar elementos
    pantalla.blit(fondo, [0,0])
    pantalla.blit(game_over_texto, (ancho/2 - (game_over_texto.get_width()/2), (altura/2 - marcador_texto.get_height() * 4)))
    pantalla.blit(tiempo_texto, (ancho/2 - (tiempo_texto.get_width()/2), (altura/2 - tiempo_texto.get_height() * 2)))
    pantalla.blit(marcador_texto, (ancho/2 - (marcador_texto.get_width()/2), (altura/2 - marcador_texto.get_height() * 3)))
    
    for jugador in all_sprites:
        jugador.kill

    pygame.display.update()
    time.sleep(5)
    pygame.quit()
    sys.exit()

fondo = pygame.image.load("fondo2.png").convert()
#---Sprites---
all_sprites = pygame.sprite.Group()
sol_list = pygame.sprite.Group()
perros_list = pygame.sprite.Group()

jugador = Jugador()
all_sprites.add(jugador)
#bucle for loop para crear tantos soles como le pidamos.
for i in range(10):
    soles = Soles()
    all_sprites.add(soles)
    sol_list.add(soles)
for i in range(5):
    perros = Perros()
    all_sprites.add(perros)
    perros_list.add(perros)
#---Game Over---
#----Timer----
Fuente = pygame.font.SysFont("serif",30)
aux=1
marcador=0
bucle = True #Bucle principal del juego.
while bucle:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            bucle = False
        
    Tiempo = pygame.time.get_ticks()//1000 
    if aux == Tiempo:
        aux+=1
        print(Tiempo)
    all_sprites.update()
    #------Coliciones-----
    catch = pygame.sprite.spritecollide(jugador, sol_list, True)
    

    golpe = pygame.sprite.spritecollide(jugador, perros_list, True)
    if golpe:
        hurt.play()
        perros = Perros()
        all_sprites.add(perros)
        perros_list.add(perros)
        marcador -=1
        jugador.hp -= 25
    if jugador.hp <= 0:
        game_over()
    if marcador == 15:
        game_win()
    if Tiempo == 30:
        game_over()

    pantalla.blit(fondo, [0, 0])
    all_sprites.draw(pantalla)
    #Marcador
    draw_text(pantalla,":"+str(marcador), 30, 260, 3.5)
    #----Timer---
    #Funcion pra mostrar el timer en pantlla.
    timer = Fuente.render("Tiempo: "+str(Tiempo),0,(255,255,255))
    barra_hp(pantalla, 600, 10, jugador.hp)
    barra_progreso(pantalla,100,10,jugador.progreso)
    pantalla.blit(timer,(50,50))
    
    pygame.display.flip()

pygame.quit()