import pygame
#Variables a necesitar
ancho = 800
altura = 600
negro = (0,0,0) #color negro 
blanco = (255,255,255) #Color blanco
pygame.init() # Inicia la libreria pygame
pantalla = pygame.display.set_mode((ancho, altura))
icono = pygame.image.load("player50.png")
pygame.display.set_icon(icono)
clock = pygame.time.Clock()
fondo = pygame.image.load("FondoMenu3.png").convert()
fuente = pygame.font.SysFont("ebrima", 25)
fuente2 = pygame.font.SysFont("arial",25)
fuente3 = pygame.font.SysFont("ebrima",21)
bucle = True #Bucle principal del juego.
while bucle:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            bucle = False
    
    pantalla.blit(fondo, [0, 0])
    Intruccion1 = fuente.render("For the first level u will need cath all the suns that will be",0,(255,255,255))
    Intruccion2 = fuente.render("apering across the level and at the same time i will need evit",0,(255,255,255))
    Intruccion3 = fuente.render("the wolf covered with harmful fog that will try stop you :D",0,(255,255,255))
    pantalla.blit(Intruccion1,(40,62))
    pantalla.blit(Intruccion2,(38,90))
    pantalla.blit(Intruccion3,(40,120))
    Intruccion4 = fuente.render("For the second level u will need go por each piece of the solar",0,(255,255,255))
    Intruccion5 = fuente.render("panel that will be appearing. And again u will evit the wolf ",0,(255,255,255))
    Intruccion6 = fuente.render("covered with that harmful fog that will try hurt you :(",0,(255,255,255))
    pantalla.blit(Intruccion4,(40,195))
    pantalla.blit(Intruccion5,(40,225))
    pantalla.blit(Intruccion6,(40,255))
    Intruccion7 = fuente.render("For the third level and the last one u will try to defend a",0,(255,255,255))
    Intruccion8 = fuente.render("dam that provides powerful energy renewable to a certain",0,(255,255,255))
    Intruccion9 = fuente.render("place and in this case u can use you store of solar energy to",0,(255,255,255))
    Intruccion10 = fuente.render("defeat with a powerful beam you enemies. Enjoy",0,(255,255,255))
    pantalla.blit(Intruccion7,(40,320))
    pantalla.blit(Intruccion8,(40,350))
    pantalla.blit(Intruccion9,(40,380))
    pantalla.blit(Intruccion10,(40,410))
    Intruccion11 = fuente.render("Principal keys",0,(255,255,255))
    Intruccion12 = fuente2.render("←, →, ↓, ↑",0,(255,255,255))
    Intruccion13 = fuente2.render("= To move across the map",0,(255,255,255))
    Intruccion14 = fuente3.render("And use SpaceBar in the third level to shoot",0,(255,255,255))
    pantalla.blit(Intruccion11,(285,480))
    pantalla.blit(Intruccion12,(170,508))
    pantalla.blit(Intruccion13,(288,510))
    pantalla.blit(Intruccion14,(165,545))
    pygame.display.flip()

pygame.quit()